<?php
$num = [
    1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
    11, 12, 13, 14, 15, 16, 17, 18,
    20, 21, 22, 23, 24,25
];


function mapped_implode($glue, $array, $symbol = '=', $sen = '>') {
    return implode($glue, array_map(
            function($k, $v) use($symbol,$sen) {
                return $sen . $k . $symbol . $v . "<br>";
            },
            array_keys($array),
            array_values($array)
            )
        );
}

$arr = ARRAY_CONTRY;

asort($arr);



