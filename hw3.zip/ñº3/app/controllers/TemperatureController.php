<?php

$temp= ARRAY_TEMPERATURE;

$value = array_slice($temp, 0, 30);
$avarage = array_sum($value) / sizeof($value);



sort($temp);

foreach ($temp as $key => $val) {
    $val ."\n";
}



$temp_min = array_slice($temp, 0, 4);

$temp_max = array_slice($temp, 26, 30);

$temp_rand = array_rand($temp, 1);



$TemperatureResult1 = "1.Average Temperature is: {$avarage}";

$TemperatureResult2 = "2. List of lowest temperatures:";

$TemperatureResult3 = "3. List of highest temperatures:";

$TemperatureResult4 = "4. Random value from a set: $temp[$temp_rand]";