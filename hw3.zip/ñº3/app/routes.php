<?php 

require_once CONTROLLERS_PATH . 'ContryController.php';
require_once CONTROLLERS_PATH . 'TemperatureController.php';

