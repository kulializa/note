<!doctype html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport"content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="public/css/style.css">
    </head>
    <body>
        <!-- task #1 -->
        <section class="task1">
            <div class="container">
                <div class="form-contry"> 
                    <h1>Task 1</h1>
                    <form action="index.php" method="POST" class="form-task1"></form>
                    <div>
                        <?php 
                            echo mapped_implode(' ', $arr, ' is ', 'The capital of '); 
                        ?>
                    </div>
                </div>
            </div>
        </section>

        <!-- task #2 -->
        <section class="task2">
            <div class="container">
                <div class="form-temperature">
                <h1>Task 2</h1>
                <div>
                    <?php 
                        echo $TemperatureResult1 ;
                        echo "<br>";
                        echo $TemperatureResult2 . "\n";
                        echo implode(",", $temp_min);
                        echo "<br>";
                        echo $TemperatureResult3 . "\n";
                        echo implode(",", $temp_max);
                        echo "<br>";
                        echo $TemperatureResult4;
                    ?>
                </div>
            </div>
            </div>
        </section>
    </body>
</html>