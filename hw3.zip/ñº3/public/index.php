<?php

require_once __DIR__ . '/../app/bootstrap.php';
require_once __DIR__ . '/../app/routes.php';

require_once VIEWS_PATH . 'master.view.php';
